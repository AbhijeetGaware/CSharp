﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignments4
{
    class SumOfRow
    {

        static void Main()
        {

            int[,] a = { { 10, 40, 30 }, { 70, 90, 80 }, { 20, 50, 60 } };
            for (int i = 0; i < 3; i++)
            {
                int sum = 0;
                for (int j = 0; j < 3; j++)
                {
                    sum = sum + a[i, j];
                }
                Console.WriteLine("sum of Row {0} ", sum);
            }

            Console.ReadLine();
        }
    }
}
