﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignments4
{
    class SearchElementJaggadArray
    {
        static void Main()
        {
            int[][] arr = new int[2][];
            arr[0] = new int[4] { 7, 8, 9, 4 };
            arr[1] = new int[3] { 6, 2, 5 };
            int num = Convert.ToInt32(Console.ReadLine());
            int inr = 0;
            for (int i = 0; i < 2; i++)
            {
                foreach (int hey in arr[i])
                {
                    if (num == hey)
                    {
                        inr++;
                    }


                }
            }
            if (inr == 1)
            {
                Console.WriteLine("number is available");
            }
            else
            {
                Console.WriteLine("number is not available");
            }
            Console.ReadLine();


        }
    }
}
