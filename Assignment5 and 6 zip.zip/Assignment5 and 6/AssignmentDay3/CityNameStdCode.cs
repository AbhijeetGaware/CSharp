﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentDay3

      // find the code program.ts file

{
    struct CityNameStdCode
    {
        public enum City
        {
            pune = 12, Beed = 23, Aurangabad = 20, Mumbai = 4
        }
       
            
        
        
    }
}
