﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentDay3

   
{

    /// <summary>
    /// simple interest ou parameter
    /// </summary>
    class SimpleIntOutPara
    {
        public static void SimpleInterest(double P, double R, double SI, double N, double TotalAmount)
        {
            Console.Write("Enter Principal(Loan Amount) : ");
            P = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter Time Period(Years) : ");
            N = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter Rate Of Interest(%) : ");
            R = Convert.ToDouble(Console.ReadLine());

            SI = P * N * (R / 100);
            TotalAmount = P + SI;

            Console.WriteLine("Interest earned : {0}", SI);
            Console.WriteLine("Final amount after interest : {0}", TotalAmount);
            Console.ReadLine();
        }
    }
}
