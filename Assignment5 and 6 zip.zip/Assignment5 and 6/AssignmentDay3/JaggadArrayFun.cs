﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentDay3
{
    class JaggadArrayFun
    {
       static void Main()
        {
            int[][] arr = new int[2][];
            arr[0] = new int[4] { 7, 8, 9, 4 };
            arr[1] = new int[3] { 6, 2, 5 };
            int num = Convert.ToInt32(Console.ReadLine());

            JaggadArrayFun obj = new JaggadArrayFun();
            obj.FindElement(num,arr);
            Console.ReadLine();
            
        }
        public void FindElement(int num, int[][] arr)
        {
            int j = 0;
            for(int i=0; i<2; i++)
            {
                foreach(var element in arr[i])
                {
                    if (element == num)
                    {
                        Console.WriteLine("number found");
                        j = 1;
                        break;
                    }
                }
                if (j == 1)
                {
                    break;

                }
                if (j == 0)
                {
                    Console.WriteLine("number not dound ");
                }
                Console.ReadLine();
            }
        }
    }
}
