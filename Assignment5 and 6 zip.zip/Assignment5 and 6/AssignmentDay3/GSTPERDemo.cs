﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentDay3
{
    class GSTPERDemo
    {
        static void Main()
        {
            GSTPERDemo obj = new GSTPERDemo();

            Console.WriteLine("Enter bill amount");
            double bill = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter rate of Gst");
            double rate = Convert.ToDouble(Console.ReadLine());

            double gst_amnt;
            obj.Calculate(bill, out gst_amnt, rate);

            Console.WriteLine("Enter gst amount {0}", gst_amnt);
            Console.ReadLine();
           
        }

        public void Calculate(double bill, out double gstamount, double gst = 1)
        {
            gstamount = gst / 100 * bill;
        }
    }
}
