﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentDay3
{
    class factUsingFun
    {
        public double factorial_Recursion(int number)
        {
            if (number == 1)

               
                return 1;
            else
                return number * factorial_Recursion(number - 1);
            
        }
       
    }
    
    }


