﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentDay3
{
    class Program
    {
        static void Main(string[] args)
        {
            foreach (string name in Enum.GetNames(typeof(CityNameStdCode.City)))
            {
                Console.WriteLine(name);
            }

            foreach (string val in Enum.GetValues(typeof(CityNameStdCode.City)))
            {
                Console.WriteLine(val);
            }
            Console.ReadLine();
        }
    }
}
