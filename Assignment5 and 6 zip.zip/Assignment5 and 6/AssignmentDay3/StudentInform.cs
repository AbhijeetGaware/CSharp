﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentDay3
{
    class StudentInform
    {
        public string name, gender;
        public int Rollno, Mobile;

       
       public StudentInform( string a, string b, int c, int d)
        {
            name = a;
            gender = b;
            Rollno = c;
            Mobile = d;
        }
       
    }
       
    class program
    {
         static void Main()
        {
            StudentInform user = new StudentInform("Deva rajpoot", "Male", 13, 907546248);
            StudentInform user1 = new StudentInform("Sangram Nana", "Male", 34, 907546244);
            Console.WriteLine("Student Name {0}",user.name);
            Console.WriteLine("student Gender {1}",user.gender);
            Console.WriteLine("student RollNo {2}",user.Rollno);
            Console.WriteLine("student Mobile {3}",user.Mobile);
            Console.WriteLine("\nPress Enter Key to Exit..");
            Console.ReadLine();
        }
    }
}
