﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentDay3
{
    class CalSimIntrFun
    {
        static void Main()
        {
           
             double P, R,  T;
             Console.Write("Enter Principal(Loan Amount) : ");
             P = Convert.ToDouble(Console.ReadLine());
             Console.Write("Enter Time Period(Years) : ");
             T = Convert.ToDouble(Console.ReadLine());
             Console.Write("Enter Rate Of Interest(%) : ");
             R = Convert.ToDouble(Console.ReadLine());

             double SI = (P * R * T) / 100;
         

             Console.WriteLine("Interest earned : {0}", SI);
             Console.WriteLine("Final amount after interest : {0}", SI);
             Console.ReadLine();

           
        }
    }
}
