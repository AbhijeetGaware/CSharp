﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day5Assignment
{
   public static class ExtensionPosNeg
    {
        public static void IsPositiveOrNegative(this int num,int value)
        {
            if (num > 0)
            {
                Console.WriteLine("Number is Positive");
            }
            else
            {
                Console.WriteLine("Number is Negetive");
            }
        }

        class TestExtension
        {
            static void Main()
            {
                int i = 20;
                i.IsPositiveOrNegative(20);
                Console.ReadLine();

            }
        }
    }
}
