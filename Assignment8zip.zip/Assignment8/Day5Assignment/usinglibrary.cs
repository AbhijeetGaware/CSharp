﻿using System;
using createlibrarytouse;

namespace Day5Assignment
{
    class usinglibrary
    {
        static void Main()
        {

            gst cl = new gst(5000);
            Console.WriteLine( cl.calgst());
            Console.ReadLine();
        }
        

        
    }
}
