﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day1Assignment
{
    class DollerToRupees
    {
        static void Main()
        {
            Console.WriteLine("Enter a doller");
            int doller = Convert.ToInt32(Console.ReadLine());
            double Rupees = doller * 71.00;

            Console.WriteLine("Doller in Rupees {0}", Rupees);

            int Rupees1 = 100;
            double doller1 = Rupees1/71.00;

            Console.WriteLine("Rupees into dollor{0}", doller1);
            Console.ReadLine();
        }
    }
}
