﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day1Assignment
    

{
    /// <summary>
    /// Calculate Of Area of circle
    /// </summary>
    class CalculateAreaOfCircle
    {
      static void Main()

        {
            Console.WriteLine("Enter the Radius:");
            int r = Convert.ToInt32(Console.ReadLine());

            const double PI = 3.14;
            
            double AOC = r * r * PI;
            Console.WriteLine("Area of Circle {0} ", AOC);
            Console.ReadLine();
        }
    }
}
