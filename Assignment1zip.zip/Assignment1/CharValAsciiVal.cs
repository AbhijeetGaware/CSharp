﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day1Assignment
{
    class CharValAsciiVal
    {
        /// <summary>
        /// Convert the Char Value to Ascii
        /// </summary>
        static void Main()
        {
            
            char d = 'a';
            int i = Convert.ToInt32(d);
            Console.WriteLine("convert the value to int {0} ", d);

            int c = 32;
            char ch = Convert.ToChar(c);
            Console.WriteLine("Convert the value to char{0} ", c);


            Console.ReadLine();


        }
    }
}
