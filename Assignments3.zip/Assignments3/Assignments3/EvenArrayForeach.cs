﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignments3
{ /// <summary>
///  Even array 
/// </summary>
    class EvenArrayForeach
    {

        static void Main()
        {
            Console.WriteLine("enter a even Number");
            int[] num = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19 };
            foreach (int demo in num)
            {
                if (demo % 2 == 0)
                {
                    Console.WriteLine(demo);
                }
            }
            Console.ReadLine();
        }
    }
}
