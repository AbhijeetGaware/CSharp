﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignments3
{   /// <summary>
///  using fun Reverse Number
/// </summary>
    class ReverseNumber
    {
        static void Main()
        {
            for (int i = 51 - 1; i >= 0; i--)
            {
                Console.WriteLine("reverse number of " + i);
            }
            Console.ReadLine();

        }
    }
}
