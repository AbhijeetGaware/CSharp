﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignments3
{
    class PrintTableDemo
    {  

        /// <summary>
        /// Print Table 
        /// </summary>
        static void Main()
        {
            int num;
            Console.WriteLine("Enter the table number");
            num = Convert.ToInt32(Console.ReadLine());
            for (int i = 1; i <= 10; i++)
            {
                Console.WriteLine("{0}*{1}={2}", num, i, i * num);
            }
            Console.ReadLine();
        }
    }
}
