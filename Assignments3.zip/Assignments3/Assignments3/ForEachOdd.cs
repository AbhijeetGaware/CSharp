﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignments3
{    
    /// <summary>
    /// For each Odd Numbers
    /// </summary>
    class ForEachOdd
    {
        static void Main()
        {
            int[] num = { 11, 12, 13, 14, 15, 16, 17, 18, 19, 20 };
            foreach (int odd in num)
            {
                if (odd % 2 != 0)
                {
                    Console.WriteLine("dispay the odd Numbers{0} ", odd);
                }
            }
            Console.ReadLine();
        }
    }
}
