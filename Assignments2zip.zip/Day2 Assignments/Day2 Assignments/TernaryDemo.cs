﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_Assignments
{
    class TernaryDemo
    {
        static void Main()
        {
            int age = Convert.ToInt32(Console.ReadLine());
            string res = age >= 18 ? "person is major" : "person is minor";
            Console.WriteLine(res);
            Console.ReadLine();
        }
        
    }
}
