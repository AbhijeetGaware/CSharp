﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_Assignments
{
    class Program
    { 
        /// <summary>
        /// Major Minor using if else
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            
            
                int a = Convert.ToInt32(Console.ReadLine()) ;
                Console.WriteLine("Enter the person ");

                if (a>=18)
                {
                    Console.WriteLine("you are major");
                }
                else
                {
                    Console.WriteLine("you are minor");
                }
            Console.ReadLine();
            }
        }
    }

