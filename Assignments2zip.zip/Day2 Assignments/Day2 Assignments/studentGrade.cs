﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2_Assignments
{
    class studentGrade
    {
        /// <summary>
        /// student Marks using if else if --else if statement
        /// </summary>
        static void Main()
        {
            
            Console.WriteLine("find the grade for each studnet");
            int Marks = Convert.ToInt32(Console.ReadLine());

            
            {
                if (Marks >= 80)
                {
                    Console.WriteLine(" student grade A");
                }else if (Marks>= 60 && Marks <80)
                {
                    Console.WriteLine( "student grade B");
                }
                else if(Marks >=35 && Marks <60)
                {
                    Console.WriteLine(  " studnet grade is C");
                }
                else
                {
                    Console.WriteLine("student grade is d");
                }

                Console.ReadLine();
            }
        }
    }
}
