﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day4Assignments
{
    class CurrantAccount : IBankAccount
    {
        double balance = 6000;
        public void Deposite(double amount)
        {
            balance = balance + amount;
            Console.WriteLine($"amount is deposited for CurrantAccount:{amount} Balance is :{balance}");
        }

        public void Withdraw(double amount)
        {
            if (amount <= balance)
            {
                balance = balance - amount;
                Console.WriteLine($"amount is withdrawn for CurrantAccount:{amount} Balance is :{balance}");
            }
            else
            {
                Console.WriteLine($"Amount Balance remaining :{ balance}");
            }
        }
    }

    class SavingAccount : IBankAccount
    {
        double balance = 0;
        public void Deposite(double amount)
        {
            balance = balance + amount;
            Console.WriteLine($"amount is deposited for SavingAccount:{amount} Balance is :{balance}");
        }

        public void Withdraw(double amount)
        {
            if (amount <= balance)
            {
                balance = balance - amount;
                Console.WriteLine($"amount is withdrawn for SavingAccount:{amount} Balance is :{balance}");
            }
            else
            {
                Console.WriteLine($"Amount Balance remaining :{ balance}");
            }
        }

         static void Main()
        {
            Console.WriteLine("Currant Account");
            CurrantAccount ca = new CurrantAccount();
            Console.WriteLine("Enter amount Deposited");
            int amnt = Convert.ToInt32(Console.ReadLine());
            ca.Deposite(amnt);

            Console.WriteLine("Enter amount withdrawn");
            int amnt1 = Convert.ToInt32(Console.ReadLine());
            ca.Withdraw(amnt1);

            Console.WriteLine("Saving  Account");
            SavingAccount sa = new SavingAccount();

            Console.WriteLine("Enter amount Deposited");
            int amnt2 = Convert.ToInt32(Console.ReadLine());
            sa.Deposite(amnt2);

            Console.WriteLine("Enter amount withdrawn");
            int amnt3 = Convert.ToInt32(Console.ReadLine());
            sa.Withdraw(amnt3);

            Console.ReadLine();


        }
    }


}
