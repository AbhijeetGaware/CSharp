﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day4Assignments
{
    class HotelRequirementDemo
    {
        class Rooms
        {
            private int _Number;
            private int _Floor;
            private string _Type;
            private int _Capacity;
            private DateTime _BookedTime;
            private double _Price;

           
            public Rooms()
            {
                Console.WriteLine("Default constructor");
            }

           

            public Rooms(int _Number, int _Floor, string _Type, int _Capacity, DateTime _BookedTime, double _Price)
            {
                this._Number =_Number;
                this._Floor = _Floor;
                this._Type = _Type;
                this._Capacity = _Capacity;
                this._BookedTime = _BookedTime;
                this._Price = _Price;

            }

            public string Show()
            {
                return string.Format("Details Of the Hotel Number= {0}, Floor {1} , Type={2}, Capacity={3}, BookedTime={4}, Price ={5}",

                    _Number, _Floor, _Type, _Capacity, _BookedTime, _Price);


            }
        }
        static void Main()
        {
            DateTime date = new DateTime(2019 / 10 / 12);

            Console.WriteLine("Enter number");
            int num= Convert.ToInt32( Console.ReadLine());

            Console.WriteLine("Enter Floor");
            int num1 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Type");
            string Type = Convert.ToString(Console.ReadLine());

            Console.WriteLine("Enter Capacity");
            int num3 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter BookedTime");
            DateTime Date = Convert.ToDateTime(Console.ReadLine());

            Console.WriteLine("Enter Price");
            int num4 = Convert.ToInt32(Console.ReadLine());
            Rooms R = new Rooms(num, num1, "Type", num3, Date, 1000);
            //NewMethod();
            //rooms r1 = new Rooms(11, 2, "Type", 7,date 1000);


            R.Show();
           
            Console.ReadLine();

        }

        
    }
}

                      

