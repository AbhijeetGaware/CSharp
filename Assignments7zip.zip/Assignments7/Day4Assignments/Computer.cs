﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day4Assignments
{
    /// <summary>
/// abstract Classes 
/// </summary>
    public abstract class Computer
    {
        public string BootUp()
        {
            return "start the Computer";
        }
        public string ShutDown()
        {
            return "Shut the Machine ";
        }
    }
    

    public class SuperComputer : Computer
    {

    }

    public class MainfraimComputer: Computer
    {

    }

    public class MicroComputer : Computer
    {

    }
    /// <summary>
    ///  Sealed Classes
    /// </summary>
    sealed class Pen
    {
        public string StartWriting()
        {
            return " Start the writing the Code";
        }

        public string StopWriting()
        {
            return "Stop writing the Code ";
        }
    }

    class MachineComputer
    {
     static void Main()
        {
            MicroComputer M = new MicroComputer();
            Console.WriteLine(M.BootUp());
            Console.WriteLine(M.ShutDown());

            Pen p = new Pen();
            Console.WriteLine(p.StartWriting());
            Console.WriteLine(p.StopWriting());

            Console.ReadLine();
        }
        
    }
}

 
