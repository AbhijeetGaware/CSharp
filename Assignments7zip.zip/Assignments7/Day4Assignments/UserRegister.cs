﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day4Assignments

{
    
    class UserRegister
    {
        private long _id;
        private string _name;
        private string _email;
        private string _DOB;

        public UserRegister()
        {

        }

        public long UserId
        {
            get
            {
                return _id;
            }
            set
            {
                _id = value;
            }
        }

        public string UserName
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }

        public string UserEmail
        {
            get
            {
                return _email;
            }
            set
            {
                _email = value;
            }
        }

        public UserRegister(long _id, string _name, string _email, string _DOB)
        {
            this._id = _id;
            this._name = _name;
            this._email = _email;
            this._DOB = _DOB;

        }

        public string UserRegisterDisplay()
        {
            return string.Format("Display the UserDetails id={0}, name= {1}, email ={2}, Dob={3}", _id,_name,_email,_DOB);
        }

        static void Main()
        {
            Console.WriteLine("Enter UserId");
            long _id = Convert.ToInt64(Console.ReadLine());

            Console.WriteLine("Enter UserName");
            string _name = Convert.ToString(Console.ReadLine());

            Console.WriteLine("Enter UserEmail");
            string _email = Convert.ToString(Console.ReadLine());

            Console.WriteLine("Enter Date of Birth");
            string _DOB = Convert.ToString(Console.ReadLine());

            UserRegister UR = new UserRegister(_id, _name, _email, _DOB);
            Console.WriteLine(UR.UserRegisterDisplay());

            Console.ReadLine();
        }


    }

  

}
